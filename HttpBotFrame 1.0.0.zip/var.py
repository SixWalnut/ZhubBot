#!/usr/bin/env python 3.10.2
# -*-coding:utf-8 -*-
#创建日期: 2022/05/12 14:15:00 
#创建者: SixWalnut
#文件描述: 全局变量提供模块

#准备好后可以导入模块了
#self lib
#none
#package lib
#none
#sys lib
#none

MessageBoard = []
exitFlag = False
Premession = {}
PluginCommandList = {}