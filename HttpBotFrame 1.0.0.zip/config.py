#!/usr/bin/env python 3.10.2
# -*-coding:utf-8 -*-
#创建日期: 2022/05/12 18:54:51 
#创建者: SixWalnut
#文件描述: 项目配置文件

#准备好后可以导入模块了
#self lib

#package lib

#sys lib

#消息发送设置
#消息推送地址
PostIP = "127.0.0.1"
#消息推送端口
PostPort = "1044"

#消息接收设置
#消息接收端口 需要和HttpAPI中设置值保持一致
ListenPort = 

#其他设置
#主人QQ号码 权限等级最高(100)
master= ""
#默认机器人QQ号码
defaultBot = ""